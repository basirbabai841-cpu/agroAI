import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router";
import { useTheme } from "next-themes";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sprout,
  ScanSearch,
  BadgeCheck,
  Mic,
  Snowflake,
  Sun,
  Moon,
  Menu,
  X,
  ArrowUpRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";

const NAV = [
  { to: "/", label: "Home", icon: Sprout, end: true },
  { to: "/crop-doctor", label: "Crop Doctor", icon: ScanSearch },
  { to: "/registry", label: "Arhti Registry", icon: BadgeCheck },
  { to: "/advisory", label: "Voice Advisory", icon: Mic },
  { to: "/cold-chain", label: "Cold Chain", icon: Snowflake },
];

function ThemeToggle() {
  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const isDark = resolvedTheme === "dark";
  return (
    <Button
      variant="outline"
      size="icon"
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      className="shrink-0"
      onClick={() => setTheme(isDark ? "light" : "dark")}
    >
      {mounted ? (isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />) : <span className="h-4 w-4" />}
    </Button>
  );
}

export default function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMobileOpen(false);
    window.scrollTo({ top: 0 });
  }, [location.pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMobileOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="min-h-dvh flex flex-col bg-background">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:p-3 focus:bg-primary focus:text-primary-foreground focus:rounded-md"
      >
        Skip to content
      </a>

      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5 min-w-0" aria-label="AgriVision AI home">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Sprout className="h-5 w-5" />
            </span>
            <span className="font-display text-lg font-semibold tracking-tight whitespace-nowrap">
              AgriVision <span className="text-accent">AI</span>
            </span>
          </Link>

          <nav className="ml-6 hidden items-center gap-1 lg:flex" aria-label="Primary">
            {NAV.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-secondary text-foreground"
                      : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                  }`
                }
              >
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle />
            <Button asChild className="hidden sm:inline-flex">
              <Link to="/crop-doctor">
                Diagnose a crop <ArrowUpRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="lg:hidden"
              aria-label="Open menu"
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-black/50 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              aria-hidden
            />
            <motion.aside
              className="fixed inset-y-0 right-0 z-50 flex w-72 max-w-[85vw] flex-col border-l bg-background lg:hidden"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.22, ease: "easeOut" }}
              role="dialog"
              aria-label="Navigation menu"
            >
              <div className="flex items-center justify-between border-b p-4">
                <span className="font-display text-base font-semibold">Modules</span>
                <Button variant="ghost" size="icon" aria-label="Close menu" onClick={() => setMobileOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <nav className="flex flex-col gap-1 p-3" aria-label="Mobile">
                {NAV.map(({ to, label, icon: Icon, end }) => (
                  <NavLink
                    key={to}
                    to={to}
                    end={end}
                    className={({ isActive }) =>
                      `flex items-center gap-3 rounded-md px-3 py-3 text-sm font-medium transition-colors ${
                        isActive ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/60"
                      }`
                    }
                  >
                    <Icon className="h-5 w-5" />
                    {label}
                  </NavLink>
                ))}
              </nav>
              <div className="mt-auto border-t p-4">
                <Button asChild className="w-full">
                  <Link to="/crop-doctor">Diagnose a crop</Link>
                </Button>
                <p className="mt-3 text-xs text-muted-foreground">
                  Built for Pakistan's field agents, farmers & supply-chain partners.
                </p>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <main id="main" className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <div className="flex items-center gap-2.5">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground">
                <Sprout className="h-4 w-4" />
              </span>
              <span className="font-display text-base font-semibold">
                AgriVision <span className="text-accent">AI</span>
              </span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              Agricultural intelligence and risk management for Pakistan — from field
              diagnosis to verified trade and fair payment.
            </p>
          </div>
          <nav className="grid grid-cols-2 gap-x-12 gap-y-2 text-sm" aria-label="Footer">
            {NAV.map(({ to, label }) => (
              <Link key={to} to={to} className="text-muted-foreground hover:text-foreground transition-colors">
                {label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="border-t py-4">
          <p className="mx-auto max-w-7xl px-4 text-xs text-muted-foreground sm:px-6">
            © 2026 AgriVision AI · Demo environment — data persists in this browser only.
          </p>
        </div>
      </footer>

      <Toaster position="top-right" richColors />
    </div>
  );
}

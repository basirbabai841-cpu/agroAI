import wheatRust from "@/assets/wheat-rust.jpg";
import cottonLeafCurl from "@/assets/cotton-leaf-curl.jpg";
import riceBlast from "@/assets/rice-blast.jpg";

export type Severity = "Low" | "Moderate" | "High" | "Critical";

export interface DiagnosisResult {
  disease: string;
  crop: string;
  confidence: number;
  severity: Severity;
  severityScore: number; // 0-100
  remediation: string[];
  pesticide: { name: string; dosage: string; note: string };
  yieldRecovery: number; // %
  analyzedAt: string;
  sourceName: string;
}

export interface SampleCrop {
  id: string;
  name: string;
  crop: string;
  image: string;
  result: Omit<DiagnosisResult, "analyzedAt" | "sourceName">;
}

export const SAMPLE_CROPS: SampleCrop[] = [
  {
    id: "wheat-rust",
    name: "Wheat Rust",
    crop: "Triticum aestivum",
    image: wheatRust,
    result: {
      disease: "Wheat Stem Rust (Puccinia graminis f. sp. tritici)",
      crop: "Wheat — Rabi season, Punjab",
      confidence: 96.4,
      severity: "High",
      severityScore: 74,
      remediation: [
        "Isolate affected tillers; remove and burn heavily pustuled leaves to cut spore load.",
        "Apply foliar fungicide at flag-leaf stage within 48 hours for maximum protectant effect.",
        "Avoid overhead evening irrigation — prolonged leaf wetness accelerates urediniospore germination.",
        "Monitor neighbouring plots every 3 days; rust spreads wind-borne up to 5 km.",
      ],
      pesticide: {
        name: "Tebiconazole 250 EC (or Propiconazole 250 EC)",
        dosage: "0.75 L per acre in 100 L water, foliar spray",
        note: "Pre-harvest interval: 35 days. Wear N95 mask and goggles during mixing. Alternate chemistry in the next spray to avoid resistance.",
      },
      yieldRecovery: 62,
    },
  },
  {
    id: "cotton-leaf-curl",
    name: "Cotton Leaf Curl",
    crop: "Gossypium hirsutum",
    image: cottonLeafCurl,
    result: {
      disease: "Cotton Leaf Curl Virus (CLCuV, begomovirus)",
      crop: "Cotton — Sindh & South Punjab belt",
      confidence: 93.1,
      severity: "Critical",
      severityScore: 88,
      remediation: [
        "Remove and bag symptomatic leaves immediately — whiteflies transmit CLCuV plant-to-plant.",
        "Deploy 8–10 yellow sticky traps per acre to monitor and suppress whitefly vector.",
        "Spray neem-based antifeedant at dusk; avoid broad-spectrum pyrethroids that kill whitefly predators.",
        "Uproot and destroy rogue plants showing vein thickening; do not compost.",
      ],
      pesticide: {
        name: "Imidacloprid 25 WP (vector control) + NSKE 5% (neem)",
        dosage: "80 g per acre in 100 L water at dusk; repeat after 15 days",
        note: "Strictly follow pollinator-safe timing: spray only after 7 PM. CLCuV has no curative chemical — vector suppression is the only lever.",
      },
      yieldRecovery: 34,
    },
  },
  {
    id: "rice-blast",
    name: "Rice Blast",
    crop: "Oryza sativa",
    image: riceBlast,
    result: {
      disease: "Rice Blast (Magnaporthe oryzae)",
      crop: "Rice — Kharif season, Lower Sindh",
      confidence: 91.8,
      severity: "Moderate",
      severityScore: 57,
      remediation: [
        "Maintain 2–3 cm standing water in the nursery and field — blast explodes under alternate wetting/drying.",
        "Avoid excessive urea top-dressing; blast is strongly favoured by lush nitrogen-rich tissue.",
        "Apply fungicide at tillering and again at panicle initiation if lesions multiply.",
        "Drain the field 24 h before any fungicide spray for better leaf retention.",
      ],
      pesticide: {
        name: "Tricyclazole 75 WP",
        dosage: "120 g per acre in 200 L water, protective spray",
        note: "Systemic protectant — must be applied before infection establishes. Do not mix with alkaline products. PHI: 30 days.",
      },
      yieldRecovery: 78,
    },
  },
];

// Deterministic pseudo-analysis for user uploads (mock CV backend).
export function analyzeUpload(seed: string): Omit<DiagnosisResult, "analyzedAt" | "sourceName"> {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  const diseases = [
    {
      disease: "Early Leaf Spot / Fungal Blight (Cercospora complex)",
      crop: "Uploaded specimen",
      pesticide: {
        name: "Chlorothalonil 75 WP",
        dosage: "250 g per acre in 100 L water",
        note: "Broad-spectrum protectant. Re-apply after 10–12 days or heavy rain. PHI: 14 days.",
      },
      remediation: [
        "Remove infected lower leaves and improve field airflow.",
        "Avoid working in the field while foliage is wet.",
        "Rotate with a non-host crop next season to reduce inoculum.",
      ],
    },
    {
      disease: "Anthracnose / Fruit Rot (Colletotrichum spp.)",
      crop: "Uploaded specimen",
      pesticide: {
        name: "Azoxystrobin 23 SC",
        dosage: "100 ml per acre in 100 L water",
        note: "Strobilurin — rotate with a multi-site fungicide to manage resistance. PHI: 7 days.",
      },
      remediation: [
        "Prune and destroy cankered twigs well below visible damage.",
        "Improve drainage around the root zone.",
        "Harvest at full maturity; wounds invite infection.",
      ],
    },
    {
      disease: "Bacterial Leaf Blight (Xanthomonas complex)",
      crop: "Uploaded specimen",
      pesticide: {
        name: "Copper Oxychloride 50 WP",
        dosage: "300 g per acre in 200 L water",
        note: "Bactericide — copper builds up in soil; limit to 3 applications per season. PHI: 20 days.",
      },
      remediation: [
        "Avoid overhead irrigation that splashes bacteria between plants.",
        "Disinfect pruning tools with 1% bleach between cuts.",
        "Do not save seed from symptomatic plants.",
      ],
    },
  ];
  const pick = diseases[h % diseases.length];
  const score = 35 + (h % 60);
  const severity: Severity = score < 45 ? "Low" : score < 65 ? "Moderate" : score < 85 ? "High" : "Critical";
  const recovery = Math.max(20, 92 - score + ((h >> 3) % 9));
  return {
    ...pick,
    confidence: 78 + ((h >> 5) % 18) + ((h >> 5) % 10) / 10,
    severity,
    severityScore: score,
    yieldRecovery: recovery,
  };
}

/* ---------------- Voice & Dialect Advisory Hub ---------------- */

export interface Dialect {
  id: string;
  label: string;
  native: string;
  region: string;
  advisory: string; // regional phrasing
  phonetic: string; // romanized phonetic guide
  latin: string;
}

export const DIALECTS: Dialect[] = [
  {
    id: "urdu",
    label: "Urdu",
    native: "اردو",
    region: "National lingua franca",
    advisory: "پانی صبح سویرے دیں، شام کو نہیں۔ زنگ کے دھبوں والی پتّیاں فوراً جلا دیں اور فنگی سائیڈ کا سپرے 48 گھنٹوں کے اندر کریں۔",
    phonetic: "Paani subah savere dein, shaam ko nahin. Zang ke dhabbon wali pattiyan foran jala dein aur fungi-side ka spray 48 ghanton ke andar karein.",
    latin: "Water at dawn, never at dusk. Burn rust-spotted leaves immediately and spray fungicide within 48 hours.",
  },
  {
    id: "pashto",
    label: "Pashto",
    native: "پښتو",
    region: "Khyber Pakhtunkhwa",
    advisory: "د خړوبۍ اوبه سهار وکړئ، ماښام مه کوئ. د زنگ پټوالي ولرې وسوځوئ او د فنجایسایډ سپری ۴۸ ساعتو کې وکړئ۔",
    phonetic: "Da kharobay obe sahar wakhrī, māshām ma koī. Də zang paṭwaley wlare wəswazhawaī au də funjisāīd spray 48 sāʿato ké wakāī.",
    latin: "Irrigate in the morning, not at dusk. Burn the rust-marked leaves and spray fungicide within 48 hours.",
  },
  {
    id: "sindhi",
    label: "Sindhi",
    native: "سنڌي",
    region: "Sindh",
    advisory: "پاڻي صبح جو ڏيو، شام جو نه۔ زنگ واريون پنڻيون ساڻ سڌو ساڙيو ۽ ٤٨ ڪلاڪن ۾ فنگي سائيڊ اسپري ڪريو۔",
    phonetic: "Paaṇee subah jo dīyo, shaam jo na. Zang waariyun panḍiyun saañ suḍho sāṛiyo aen 48 klaakan mein fungi-sāīḍ spray kareo.",
    latin: "Give water in the morning, not the evening. Burn the rusted leaves at once and spray fungicide within 48 hours.",
  },
  {
    id: "balochi",
    label: "Balochi",
    native: "بلوچی",
    region: "Balochistan",
    advisory: "آب صبح آ بئے، ماپین مَہ بئے۔ زنگے پتک پیش کنگ آتک اته آ سپرے ۴۸ ساعته آ اندر کنگ۔",
    phonetic: "Āb subā ā bay, māpēn ma bay. Zange patk pēsh kanag ātk ataa ā spray 48 sāata ā andar kanag.",
    latin: "Water in the morning, not at dusk. Burn the rusted leaves and spray within 48 hours.",
  },
  {
    id: "brahui",
    label: "Brahui",
    native: "براہوی",
    region: "Central Balochistan",
    advisory: "آب سوب آ بہ، شام آ نہ بہ۔ زنگے پٹک مڑّے ماسیں آ ۴۸ سات آ دن اسپرے کنیں۔",
    phonetic: "Āb sob ā bā, shām ā na bā. Zange paṭk maṛḍe maasái ā 48 sāt ā dan spray kanái.",
    latin: "Water in the morning, not in the evening. Burn the rusted leaves and spray within 48 hours.",
  },
  {
    id: "seraiki",
    label: "Seraiki",
    native: "سرائیکی",
    region: "South Punjab",
    advisory: "پاݨ سویرے ݙیو، شام کوں نی۔ زنگ آلی پَڻّیاں ڄل تے ساڑ ݙیو تے ٤٨ گھنٹے اٖچ سپرے کرو۔",
    phonetic: "Pāṇ soverai ḍe-o, shaam koṇ nē. Zang āli paṇṇiyã jal te sāṛ ḍe-o te 48 ghanté ich spray karo.",
    latin: "Water at dawn, not at dusk. Burn the rusted leaves and spray within 48 hours.",
  },
];

/* ---------------- Cold-chain ---------------- */

export const COLD_CHAIN_THRESHOLDS = {
  temp: { min: 2, max: 8 }, // °C safe band for fresh produce
  humidity: { min: 75, max: 92 }, // % RH
};

export interface TelemetryPoint {
  t: number; // minutes
  temp: number;
  humidity: number;
  doorOpen: boolean;
}

export interface TripRecord {
  id: string;
  truck: string;
  route: string;
  produce: string;
  farmer: string;
  amountPKR: number;
  startedAt: string;
  durationMin: number;
  avgTemp: number;
  avgHumidity: number;
  breachMinutes: number;
  verdict: "RELEASED" | "HELD";
  releaseTx: string | null;
}

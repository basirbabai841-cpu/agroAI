import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Snowflake,
  Play,
  Pause,
  RotateCcw,
  Thermometer,
  Droplets,
  ShieldCheck,
  ShieldAlert,
  Truck,
  HandCoins,
  History,
  Trash2,
  DoorOpen,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceArea,
  ReferenceLine,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { COLD_CHAIN_THRESHOLDS, type TelemetryPoint, type TripRecord } from "@/lib/data";
import { load, save, uid } from "@/lib/store";

const TRIP_DURATION = 90; // simulated minutes: Okara → Lahore mandi
const TICK_SIM_MIN = 2; // each real second = 2 sim minutes
const TICK_MS = 1000;

interface SimState {
  t: number;
  temp: number;
  humidity: number;
  cooling: number; // 0..1
  solar: number; // 0..1
  doorOpenTicks: number;
  points: TelemetryPoint[];
  breachMin: number;
}

const FARMERS = [
  { name: "Muhammad Ramzan", village: "Chak 4/4-L, Okara", produce: "Fresh okra", amount: 184500 },
  { name: "Bibi Shamim", village: "Tando Jam, Hyderabad", produce: "Cherry tomatoes", amount: 262000 },
  { name: "Abdul Sattar", village: "Mureedwala, Faisalabad", produce: "Green chillies", amount: 148750 },
];

export default function ColdChain() {
  const [running, setRunning] = useState(false);
  const [solar, setSolar] = useState(0.55);
  const [cooling, setCooling] = useState(0.85);
  const [sim, setSim] = useState<SimState>({
    t: 0,
    temp: 5.2,
    humidity: 86,
    cooling: 0.85,
    solar: 0.55,
    doorOpenTicks: 0,
    points: [{ t: 0, temp: 5.2, humidity: 86, doorOpen: false }],
    breachMin: 0,
  });
  const [escrow, setEscrow] = useState(FARMERS[0]);
  const [verdict, setVerdict] = useState<TripRecord | null>(null);
  const [trips, setTrips] = useState<TripRecord[]>(() => load<TripRecord[]>("coldchain-trips", []));
  const intervalRef = useRef<number | null>(null);
  const solarRef = useRef(solar);
  const coolingRef = useRef(cooling);
  solarRef.current = solar;
  coolingRef.current = cooling;

  useEffect(() => {
    save("coldchain-trips", trips);
  }, [trips]);

  const inTempBand = (temp: number) => temp >= COLD_CHAIN_THRESHOLDS.temp.min && temp <= COLD_CHAIN_THRESHOLDS.temp.max;
  const inHumBand = (h: number) => h >= COLD_CHAIN_THRESHOLDS.humidity.min && h <= COLD_CHAIN_THRESHOLDS.humidity.max;

  const finishTrip = useCallback((final: SimState) => {
    setRunning(false);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    const breachRatio = final.breachMin / TRIP_DURATION;
    const released = breachRatio <= 0.15;
    const record: TripRecord = {
      id: uid("TRIP"),
      truck: "AVT-2271 · Isuzu Reefer",
      route: "Okara → Lahore New Anarkali Mandi",
      produce: escrow.produce,
      farmer: escrow.name,
      amountPKR: escrow.amount,
      startedAt: new Date().toISOString(),
      durationMin: final.t,
      avgTemp: final.points.reduce((a, p) => a + p.temp, 0) / final.points.length,
      avgHumidity: final.points.reduce((a, p) => a + p.humidity, 0) / final.points.length,
      breachMinutes: final.breachMin,
      verdict: released ? "RELEASED" : "HELD",
      releaseTx: released
        ? `0x${Array.from({ length: 40 }, () => "0123456789abcdef"[Math.floor(Math.random() * 16)]).join("")}`
        : null,
    };
    setVerdict(record);
    setTrips((tr) => [record, ...tr].slice(0, 8));
    if (released) {
      toast.success(`Escrow released — PKR ${record.amountPKR.toLocaleString()} paid to ${record.farmer}.`);
    } else {
      toast.error(
        `Escrow held — ${final.breachMin} min outside safe band (${Math.round(breachRatio * 100)}%). Docking blocked; inspection triggered.`,
        { duration: 6000 }
      );
    }
  }, [escrow]);

  const tick = useCallback(() => {
    setSim((prev) => {
      const ambient = 28 + solarRef.current * 12; // 28–40 °C
      const coolingPower = coolingRef.current;
      const doorOpen = prev.doorOpenTicks > 0 || Math.random() < 0.045;

      // thermal model: cooling pulls toward 3.8°C, ambient leaks in at a rate modulated by solar & door
      let temp = prev.temp;
      const leak = (0.02 + solarRef.current * 0.035) * (1 - coolingPower * 0.75);
      temp += (ambient - temp) * leak * TICK_SIM_MIN;
      temp += (3.8 - temp) * 0.22 * coolingPower * TICK_SIM_MIN;
      if (doorOpen) temp += 1.2;
      temp += (Math.random() - 0.5) * 0.4;

      let humidity = prev.humidity;
      const recovery = Math.max(0, (90 - prev.humidity) / 10); // eases off near 90% RH
      humidity += (doorOpen ? -1.8 : 1.1 * coolingPower * recovery) * TICK_SIM_MIN * 0.4;
      humidity = Math.max(40, Math.min(99, humidity));
      temp = Math.round(temp * 10) / 10;

      const t = prev.t + TICK_SIM_MIN;
      const breach = !inTempBand(temp) || !inHumBand(humidity);
      const next: SimState = {
        ...prev,
        t,
        temp,
        humidity: Math.round(humidity),
        doorOpenTicks: doorOpen ? (prev.doorOpenTicks > 0 ? prev.doorOpenTicks - 1 : 2) : 0,
        breachMin: prev.breachMin + (breach ? TICK_SIM_MIN : 0),
        points: [...prev.points, { t, temp, humidity: Math.round(humidity), doorOpen }],
      };
      if (t >= TRIP_DURATION) {
        // defer side effects out of the updater
        setTimeout(() => finishTrip(next), 0);
        return next;
      }
      return next;
    });
  }, [finishTrip]);

  const start = () => {
    if (sim.t >= TRIP_DURATION) {
      reset();
    }
    setVerdict(null);
    setRunning(true);
  };

  const pause = () => {
    setRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
  };

  const reset = () => {
    pause();
    setSim({
      t: 0,
      temp: 5.2,
      humidity: 86,
      cooling: coolingRef.current,
      solar: solarRef.current,
      doorOpenTicks: 0,
      points: [{ t: 0, temp: 5.2, humidity: 86, doorOpen: false }],
      breachMin: 0,
    });
    setVerdict(null);
  };

  useEffect(() => {
    if (running) {
      intervalRef.current = window.setInterval(tick, TICK_MS);
      return () => {
        if (intervalRef.current) clearInterval(intervalRef.current);
      };
    }
  }, [running, tick]);

  useEffect(() => () => pause(), []);

  const breachRatio = sim.breachMin / Math.max(sim.t, 1);
  const liveRisk = Math.min(
    100,
    Math.round(breachRatio * 120 + (inTempBand(sim.temp) ? 0 : 12) + (inHumBand(sim.humidity) ? 0 : 6) + (sim.doorOpenTicks > 0 ? 8 : 0))
  );
  const tempOk = inTempBand(sim.temp);
  const humOk = inHumBand(sim.humidity);
  const progressPct = Math.min(100, (sim.t / TRIP_DURATION) * 100);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent">Supply-Chain Risk</p>
        <h1 className="font-display mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">Cold-Chain Sentinel</h1>
        <p className="mt-3 text-muted-foreground">
          Live IoT telemetry from reefer trucks on rural routes. A conditional escrow contract pays
          the smallholder automatically — but only if the produce arrives inside the safe band, making
          broker price-docking impossible.
        </p>
      </div>

      {/* truck strip */}
      <Card className="mt-8">
        <CardContent className="p-5">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
            <div className="flex items-center gap-3">
              <span className="relative grid h-11 w-11 place-items-center rounded-xl bg-primary text-primary-foreground">
                <Truck className="h-5 w-5" />
                {running && <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-success animate-pulse" />}
              </span>
              <div>
                <p className="text-sm font-bold">AVT-2271 · Isuzu Reefer</p>
                <p className="text-xs text-muted-foreground">Okara → Lahore New Anarkali Mandi · ~{TRIP_DURATION} min</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div>
                <p className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                  <Thermometer className="h-3.5 w-3.5" /> Temp
                </p>
                <p className={`font-display text-2xl font-semibold ${tempOk ? "text-success" : "text-destructive"}`}>
                  {sim.temp.toFixed(1)}°C
                </p>
              </div>
              <div>
                <p className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                  <Droplets className="h-3.5 w-3.5" /> Humidity
                </p>
                <p className={`font-display text-2xl font-semibold ${humOk ? "text-success" : "text-warning"}`}>
                  {sim.humidity}%
                </p>
              </div>
              <div>
                <p className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                  <Snowflake className="h-3.5 w-3.5" /> Door
                </p>
                <p className={`font-display text-2xl font-semibold ${sim.doorOpenTicks > 0 ? "text-warning" : ""}`}>
                  {sim.doorOpenTicks > 0 ? "Open" : "Sealed"}
                </p>
              </div>
            </div>

            <div className="ml-auto flex flex-wrap gap-2">
              <Button onClick={running ? pause : start} size="lg" variant={running ? "outline" : "default"}>
                {running ? <Pause className="mr-1.5 h-4 w-4" /> : <Play className="mr-1.5 h-4 w-4" />}
                {running ? "Pause" : sim.t > 0 && sim.t < TRIP_DURATION ? "Resume" : "Start trip"}
              </Button>
              <Button onClick={reset} variant="outline" size="lg">
                <RotateCcw className="mr-1.5 h-4 w-4" /> Reset
              </Button>
            </div>
          </div>

          {/* route progress */}
          <div className="mt-4">
            <div className="flex justify-between text-xs font-medium text-muted-foreground">
              <span>Chak 4/4-L farm gate</span>
              <span>
                {Math.min(sim.t, TRIP_DURATION)} / {TRIP_DURATION} min
              </span>
              <span>Lahore mandi</span>
            </div>
            <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-secondary">
              <motion.div
                className={`h-full rounded-full ${breachRatio > 0.15 ? "bg-destructive" : "bg-success"}`}
                animate={{ width: `${progressPct}%` }}
                transition={{ duration: 0.4 }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        {/* telemetry chart */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Thermometer className="h-4 w-4 text-accent" /> Live telemetry
              <Badge variant="outline" className="ml-auto">
                safe {COLD_CHAIN_THRESHOLDS.temp.min}–{COLD_CHAIN_THRESHOLDS.temp.max}°C ·{" "}
                {COLD_CHAIN_THRESHOLDS.humidity.min}–{COLD_CHAIN_THRESHOLDS.humidity.max}% RH
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sim.points} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="t" tickFormatter={(v) => `${v}m`} className="text-xs" tick={{ fontSize: 11 }} />
                  <YAxis yAxisId="temp" domain={[0, 24]} tick={{ fontSize: 11 }} />
                  <YAxis yAxisId="hum" orientation="right" domain={[40, 100]} hide />
                  <Tooltip
                    formatter={(value: number, name: string) => [
                      name === "temp" ? `${value}°C` : `${value}%`,
                      name === "temp" ? "Temperature" : "Humidity",
                    ]}
                    labelFormatter={(l) => `Minute ${l}`}
                  />
                  <ReferenceArea
                    yAxisId="temp"
                    y1={COLD_CHAIN_THRESHOLDS.temp.min}
                    y2={COLD_CHAIN_THRESHOLDS.temp.max}
                    fill="hsl(var(--success))"
                    fillOpacity={0.08}
                  />
                  <ReferenceLine
                    yAxisId="temp"
                    y={COLD_CHAIN_THRESHOLDS.temp.max}
                    stroke="hsl(var(--destructive))"
                    strokeDasharray="4 4"
                  />
                  <ReferenceLine
                    yAxisId="temp"
                    y={COLD_CHAIN_THRESHOLDS.temp.min}
                    stroke="hsl(var(--info))"
                    strokeDasharray="4 4"
                  />
                  <Line yAxisId="temp" type="monotone" dataKey="temp" stroke="hsl(var(--warning))" strokeWidth={2.2} dot={false} isAnimationActive={false} />
                  <Line yAxisId="hum" type="monotone" dataKey="humidity" stroke="hsl(var(--info))" strokeWidth={1.8} dot={false} isAnimationActive={false} opacity={0.8} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* environment controls */}
            <div className="mt-5 grid gap-5 sm:grid-cols-2">
              <div>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span className="font-medium">Solar load</span>
                  <span className="text-muted-foreground">{Math.round(solar * 100)}%</span>
                </div>
                <Slider value={[solar * 100]} onValueChange={(v) => setSolar(v[0] / 100)} max={100} step={5} aria-label="Solar load" />
                <p className="mt-1 text-xs text-muted-foreground">How hard the Punjab sun beats on the container.</p>
              </div>
              <div>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span className="font-medium">Cooling unit power</span>
                  <span className="text-muted-foreground">{Math.round(cooling * 100)}%</span>
                </div>
                <Slider value={[cooling * 100]} onValueChange={(v) => setCooling(v[0] / 100)} max={100} step={5} aria-label="Cooling power" />
                <p className="mt-1 text-xs text-muted-foreground">Diesel Reefer setting — cut it to simulate breakdowns.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* escrow panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <HandCoins className="h-4 w-4 text-accent" /> Conditional escrow
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-xl border bg-secondary/40 p-4">
                <p className="text-sm font-bold">{escrow.name}</p>
                <p className="text-xs text-muted-foreground">{escrow.village}</p>
                <div className="mt-3 flex items-end justify-between">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Contract value</p>
                    <p className="font-display text-2xl font-semibold">PKR {escrow.amount.toLocaleString()}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{escrow.produce}</p>
                </div>
              </div>

              {/* risk + verdict */}
              <div>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span className="font-medium">Spoilage risk</span>
                  <span
                    className={`font-bold ${
                      liveRisk < 30 ? "text-success" : liveRisk < 60 ? "text-warning" : "text-destructive"
                    }`}
                  >
                    {liveRisk}%
                  </span>
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-secondary">
                  <motion.div
                    className={`h-full rounded-full ${
                      liveRisk < 30 ? "bg-success" : liveRisk < 60 ? "bg-warning" : "bg-destructive"
                    }`}
                    animate={{ width: `${liveRisk}%` }}
                    transition={{ duration: 0.4 }}
                  />
                </div>
                <p className="mt-1.5 text-xs text-muted-foreground">
                  {sim.breachMin} min outside safe band so far (escrow voids above 15% of trip)
                </p>
              </div>

              <AnimatePresence mode="wait">
                {verdict ? (
                  <motion.div
                    key={verdict.id}
                    initial={{ opacity: 0, y: 12, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className={`rounded-xl border p-4 ${
                      verdict.verdict === "RELEASED"
                        ? "border-success/40 bg-success/10"
                        : "border-destructive/40 bg-destructive/10"
                    }`}
                  >
                    <p className="flex items-center gap-2 font-bold">
                      {verdict.verdict === "RELEASED" ? (
                        <ShieldCheck className="h-5 w-5 text-success" />
                      ) : (
                        <ShieldAlert className="h-5 w-5 text-destructive" />
                      )}
                      {verdict.verdict === "RELEASED" ? "Payment released in full" : "Payment held — docking blocked"}
                    </p>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {verdict.verdict === "RELEASED"
                        ? `${verdict.farmer} receives PKR ${verdict.amountPKR.toLocaleString()} — produce arrived in spec. No broker margin deducted.`
                        : `${verdict.farmer}'s payment is protected in escrow. ${verdict.breachMinutes} min of threshold breach triggered a third-party inspection instead of arbitrary price-docking.`}
                    </p>
                    {verdict.releaseTx && (
                      <p className="mt-2 break-all text-[11px] font-mono text-muted-foreground">
                        Tx {verdict.releaseTx.slice(0, 22)}…
                      </p>
                    )}
                  </motion.div>
                ) : (
                  <motion.div key="pending" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <div className="flex items-start gap-2.5 rounded-xl border p-4 text-sm text-muted-foreground">
                      <DoorOpen className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
                      Escrow is armed. The contract auto-releases on arrival within thresholds —
                      trip in progress{running ? "" : sim.t === 0 ? " (press Start)" : " (paused)"}.
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div>
                <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Shipper profile</p>
                <div className="grid grid-cols-3 gap-2">
                  {FARMERS.map((f) => (
                    <button
                      key={f.name}
                      onClick={() => setEscrow(f)}
                      disabled={running}
                      className={`rounded-lg border px-2 py-2 text-left text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 ${
                        escrow.name === f.name ? "border-accent bg-accent/10 font-semibold" : "bg-secondary/30 hover:border-accent/50"
                      }`}
                    >
                      {f.name.split(" ").slice(0, 2).join(" ")}
                      <span className="block font-normal text-muted-foreground">{f.produce}</span>
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {trips.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <History className="h-4 w-4 text-accent" /> Trip log
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setTrips([]);
                      toast.info("Trip log cleared.");
                    }}
                  >
                    <Trash2 className="mr-1 h-3.5 w-3.5" /> Clear
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {trips.slice(0, 5).map((tr) => (
                  <div key={tr.id} className="flex items-center justify-between gap-3 rounded-lg border bg-secondary/30 px-3 py-2.5 text-sm">
                    <div className="min-w-0">
                      <p className="truncate font-medium">{tr.farmer}</p>
                      <p className="text-xs text-muted-foreground">
                        avg {tr.avgTemp.toFixed(1)}°C · breach {tr.breachMinutes}m ·{" "}
                        {new Date(tr.startedAt).toLocaleTimeString()}
                      </p>
                    </div>
                    <Badge
                      variant="outline"
                      className={
                        tr.verdict === "RELEASED"
                          ? "text-success border-success/40 bg-success/10"
                          : "text-destructive border-destructive/40 bg-destructive/10"
                      }
                    >
                      {tr.verdict}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Upload,
  ScanLine,
  FlaskConical,
  Leaf,
  History,
  Trash2,
  Gauge,
  Pill,
  Sprout,
  CheckCircle2,
  CircleDashed,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SAMPLE_CROPS, analyzeUpload, type DiagnosisResult, type Severity } from "@/lib/data";
import { load, save, uid } from "@/lib/store";

type Phase = "idle" | "scanning" | "analyzing" | "done";

interface ScanRecord {
  id: string;
  result: DiagnosisResult;
}

const SEVERITY_STYLES: Record<Severity, string> = {
  Low: "text-success border-success/40 bg-success/10",
  Moderate: "text-warning border-warning/40 bg-warning/10",
  High: "text-orange-400 border-orange-400/40 bg-orange-400/10",
  Critical: "text-destructive border-destructive/40 bg-destructive/10",
};

function severityColor(s: Severity): string {
  return s === "Low" ? "hsl(var(--success))" : s === "Moderate" ? "hsl(var(--warning))" : s === "High" ? "#fb923c" : "hsl(var(--destructive))";
}

/* Circular severity gauge */
function GaugeRing({ score, severity }: { score: number; severity: Severity }) {
  const r = 52;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative mx-auto h-36 w-36">
      <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
        <circle cx="60" cy="60" r={r} fill="none" strokeWidth="10" className="stroke-secondary" />
        <motion.circle
          cx="60"
          cy="60"
          r={r}
          fill="none"
          strokeWidth="10"
          strokeLinecap="round"
          stroke={severityColor(severity)}
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - score / 100) }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-3xl font-semibold">{score}</span>
        <span className="text-xs font-medium text-muted-foreground">/ 100</span>
      </div>
    </div>
  );
}

export default function CropDoctor() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [customImage, setCustomImage] = useState<string | null>(null);
  const [customName, setCustomName] = useState("");
  const [result, setResult] = useState<DiagnosisResult | null>(null);
  const [history, setHistory] = useState<ScanRecord[]>(() => load<ScanRecord[]>("crop-doctor-history", []));
  const fileRef = useRef<HTMLInputElement>(null);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  useEffect(() => {
    save("crop-doctor-history", history);
  }, [history]);

  const runScan = useCallback(
    (_image: string, base: Omit<DiagnosisResult, "analyzedAt" | "sourceName">, sourceName: string) => {
      if (phase === "scanning" || phase === "analyzing") return;
      setPhase("scanning");
      setProgress(0);
      setResult(null);

      const scanDur = 2400;
      const start = performance.now();
      let raf = 0;
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / scanDur);
        setProgress(p);
        if (p < 1) raf = requestAnimationFrame(tick);
        else {
          setPhase("analyzing");
          timers.current.push(
            window.setTimeout(() => {
              const full: DiagnosisResult = {
                ...base,
                analyzedAt: new Date().toISOString(),
                sourceName,
              };
              setResult(full);
              setPhase("done");
              setHistory((h) => [{ id: uid("SCAN"), result: full }, ...h].slice(0, 8));
              toast.success(`Diagnosis complete — ${full.severity} severity ${full.disease.split("(")[0].trim()}`);
            }, 1100)
          );
        }
      };
      raf = requestAnimationFrame(tick);
      timers.current.push(raf as unknown as number);
    },
    [phase]
  );

  const scanSample = (id: string) => {
    const sample = SAMPLE_CROPS.find((s) => s.id === id);
    if (!sample) return;
    setSelectedId(id);
    setCustomImage(null);
    runScan(sample.image, sample.result, sample.name);
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload an image file (JPG, PNG, WebP).");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      setCustomImage(dataUrl);
      setCustomName(file.name);
      setSelectedId(null);
      const seed = `${file.name}:${file.size}:${file.lastModified}`;
      runScan(dataUrl, analyzeUpload(seed), file.name);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const clearHistory = () => {
    setHistory([]);
    toast.info("Scan history cleared.");
  };

  const activeImage = customImage ?? (selectedId ? SAMPLE_CROPS.find((s) => s.id === selectedId)?.image ?? null : null);
  const busy = phase === "scanning" || phase === "analyzing";

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent">Crop Loss Prevention</p>
        <h1 className="font-display mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">AI Crop Doctor</h1>
        <p className="mt-3 text-muted-foreground">
          Select a specimen or upload a field photo. The vision engine sweeps the canopy with a
          diagnostic laser, then returns severity, remediation, safe dosage and expected yield recovery.
        </p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        {/* ---------- Scanner panel ---------- */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <ScanLine className="h-4 w-4 text-accent" /> Specimen scanner
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* sample chips */}
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Sample specimens
              </p>
              <div className="grid grid-cols-3 gap-2">
                {SAMPLE_CROPS.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => scanSample(s.id)}
                    disabled={busy}
                    className={`group relative overflow-hidden rounded-xl border text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60 ${
                      selectedId === s.id ? "border-accent ring-1 ring-accent" : "hover:border-accent/50"
                    }`}
                  >
                    <img src={s.image} alt={s.name} className="aspect-square w-full object-cover" />
                    <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent px-2 pb-1.5 pt-6 text-[11px] font-semibold text-white">
                      {s.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* upload */}
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Or upload a field photo
              </p>
              <button
                onClick={() => fileRef.current?.click()}
                disabled={busy}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-input bg-secondary/40 px-4 py-5 text-sm font-medium text-muted-foreground transition-colors hover:border-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60"
              >
                <Upload className="h-4 w-4" />
                {customName || "Choose image…"}
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onFile} aria-label="Upload crop photo" />
            </div>

            {/* scan stage */}
            <div className="relative overflow-hidden rounded-xl border bg-secondary/30">
              {activeImage ? (
                <div className="relative">
                  <img src={activeImage} alt="Specimen under scan" className="aspect-[4/3] w-full object-cover" />
                  {/* scan grid overlay */}
                  <div
                    className="absolute inset-0 opacity-25"
                    style={{
                      backgroundImage:
                        "linear-gradient(hsl(var(--accent)/.6) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--accent)/.6) 1px, transparent 1px)",
                      backgroundSize: "28px 28px",
                    }}
                    aria-hidden
                  />
                  <AnimatePresence>
                    {phase === "scanning" && (
                      <>
                        <motion.div
                          className="scan-glow absolute inset-x-0"
                          style={{ top: 0, height: "40%" }}
                          initial={{ y: "-110%" }}
                          animate={{ y: `${(progress * 340).toFixed(1)}%` }}
                          transition={{ ease: "linear", duration: 0.05 }}
                          aria-hidden
                        />
                        <motion.div
                          className="scan-line"
                          initial={{ top: "0%" }}
                          animate={{ top: `${(progress * 100).toFixed(1)}%` }}
                          transition={{ ease: "linear", duration: 0.05 }}
                          aria-hidden
                        />
                      </>
                    )}
                  </AnimatePresence>

                  {/* phase status pill */}
                  <div className="absolute left-3 top-3 flex items-center gap-2 rounded-full bg-black/60 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur">
                    {phase === "scanning" && (
                      <>
                        <ScanLine className="h-3.5 w-3.5 animate-pulse text-accent" />
                        Sweeping canopy… {Math.round(progress * 100)}%
                      </>
                    )}
                    {phase === "analyzing" && (
                      <>
                        <FlaskConical className="h-3.5 w-3.5 animate-spin text-accent" />
                        Classifying pathogen…
                      </>
                    )}
                    {phase === "done" && (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5 text-success" />
                        Analysis complete
                      </>
                    )}
                    {phase === "idle" && (
                      <>
                        <CircleDashed className="h-3.5 w-3.5" />
                        Awaiting specimen
                      </>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex aspect-[4/3] flex-col items-center justify-center gap-3 text-muted-foreground">
                  <Leaf className="h-10 w-10 opacity-40" />
                  <p className="text-sm">Pick a sample or upload a photo to begin scanning</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* ---------- Results panel ---------- */}
        <div className="space-y-4">
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key={result.analyzedAt}
                initial={{ opacity: 0, y: 14, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
                className="space-y-4"
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <CardTitle className="text-base">Diagnosis</CardTitle>
                      <Badge variant="outline" className={SEVERITY_STYLES[result.severity]}>
                        {result.severity} severity
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-5">
                    <div>
                      <p className="font-display text-lg font-semibold leading-snug">{result.disease}</p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {result.crop} · confidence {result.confidence.toFixed(1)}% ·{" "}
                        {new Date(result.analyzedAt).toLocaleString()}
                      </p>
                    </div>

                    <div className="grid items-center gap-5 sm:grid-cols-[auto_1fr]">
                      <GaugeRing score={result.severityScore} severity={result.severity} />
                      <div className="grid grid-cols-2 gap-3">
                        <div className="rounded-xl border bg-secondary/40 p-3">
                          <p className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                            <Sprout className="h-3.5 w-3.5" /> Yield recovery
                          </p>
                          <p className="font-display mt-1 text-2xl font-semibold text-success">
                            ~{result.yieldRecovery}%
                          </p>
                          <p className="text-[11px] text-muted-foreground">if plan followed within 72h</p>
                        </div>
                        <div className="rounded-xl border bg-secondary/40 p-3">
                          <p className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                            <Gauge className="h-3.5 w-3.5" /> Confidence
                          </p>
                          <p className="font-display mt-1 text-2xl font-semibold">{result.confidence.toFixed(1)}%</p>
                          <p className="text-[11px] text-muted-foreground">model certainty</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        Immediate remediation
                      </p>
                      <ul className="space-y-2">
                        {result.remediation.map((r, i) => (
                          <li key={i} className="flex gap-2.5 text-sm leading-relaxed">
                            <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-accent/15 text-[11px] font-bold text-accent">
                              {i + 1}
                            </span>
                            {r}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="rounded-xl border border-warning/30 bg-warning/5 p-4">
                      <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-warning">
                        <Pill className="h-4 w-4" /> Safe pesticide dosage
                      </p>
                      <p className="mt-2 text-sm font-semibold">{result.pesticide.name}</p>
                      <p className="mt-0.5 text-sm">{result.pesticide.dosage}</p>
                      <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{result.pesticide.note}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <Card className="flex min-h-64 flex-col items-center justify-center gap-3 p-8 text-center text-muted-foreground">
                  <ScanLine className="h-10 w-10 opacity-40" />
                  <p className="max-w-xs text-sm">
                    No diagnosis yet. Choose a sample specimen on the left — the full structured
                    report will appear here.
                  </p>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* history */}
          {history.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <History className="h-4 w-4 text-accent" /> Recent scans
                  </CardTitle>
                  <Button variant="ghost" size="sm" onClick={clearHistory} aria-label="Clear scan history">
                    <Trash2 className="mr-1 h-3.5 w-3.5" /> Clear
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {history.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => setResult(h.result)}
                    className="flex w-full items-center justify-between gap-3 rounded-lg border bg-secondary/30 px-3 py-2.5 text-left text-sm transition-colors hover:border-accent/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-medium">{h.result.disease.split("(")[0].trim()}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(h.result.analyzedAt).toLocaleString()} · {h.result.sourceName}
                      </p>
                    </div>
                    <Badge variant="outline" className={SEVERITY_STYLES[h.result.severity]}>
                      {h.result.severity}
                    </Badge>
                  </button>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { motion, useInView } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  ScanSearch,
  BadgeCheck,
  Mic,
  Snowflake,
  Tractor,
  ShieldCheck,
  TrendingUp,
  Radio,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

/* ---------- Animated field canvas: drifting scan grid + crop rows ---------- */
function FieldCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    // pseudo-random but stable "crop" points
    const pts: { x: number; y: number; ph: number }[] = [];
    for (let i = 0; i < 46; i++) {
      pts.push({ x: Math.random(), y: Math.random(), ph: Math.random() * Math.PI * 2 });
    }

    const css = getComputedStyle(document.documentElement);
    const accent = css.getPropertyValue("--accent").trim();
    const primary = css.getPropertyValue("--primary").trim();

    let t = 0;
    const draw = () => {
      t += 0.008;
      ctx.clearRect(0, 0, w, h);

      // perspective crop rows
      const horizon = h * 0.42;
      ctx.strokeStyle = `hsl(${primary} / 0.35)`;
      ctx.lineWidth = 1;
      for (let i = -10; i <= 10; i++) {
        ctx.beginPath();
        ctx.moveTo(w / 2 + i * 14, horizon);
        ctx.lineTo(w / 2 + i * w * 0.16, h + 40);
        ctx.stroke();
      }
      for (let i = 0; i < 9; i++) {
        const p = i / 9;
        const y = horizon + Math.pow(p, 1.7) * (h - horizon);
        ctx.strokeStyle = `hsl(${primary} / ${0.06 + p * 0.2})`;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // drifting data points
      for (const p of pts) {
        const y = horizon + Math.pow(p.y, 1.4) * (h - horizon);
        const x = p.x * w;
        const pulse = 0.5 + 0.5 * Math.sin(t * 2 + p.ph);
        ctx.fillStyle = `hsl(${accent} / ${0.15 + pulse * 0.55})`;
        ctx.beginPath();
        ctx.arc(x, y, 1.4 + pulse * 1.8, 0, Math.PI * 2);
        ctx.fill();
      }

      // horizontal scan sweep
      const sy = horizon + ((t * 60) % (h - horizon + 60)) - 30;
      const grad = ctx.createLinearGradient(0, sy - 26, 0, sy + 26);
      grad.addColorStop(0, `hsl(${accent} / 0)`);
      grad.addColorStop(0.5, `hsl(${accent} / 0.16)`);
      grad.addColorStop(1, `hsl(${accent} / 0)`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, sy - 26, w, 52);
      ctx.fillStyle = `hsl(${accent} / 0.5)`;
      ctx.fillRect(0, sy - 0.5, w, 1);

      if (!reduced) raf = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={ref} className="absolute inset-0 h-full w-full" aria-hidden />;
}

/* ---------- Count-up metric ---------- */
function Metric({ value, suffix, label, decimals = 0 }: { value: number; suffix: string; label: string; decimals?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setDisplay(value);
      return;
    }
    const start = performance.now();
    const dur = 1400;
    let raf = 0;
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(value * eased);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [inView, value]);

  return (
    <div ref={ref}>
      <p className="font-display text-3xl font-semibold sm:text-4xl">
        {display.toFixed(decimals)}
        <span className="text-accent">{suffix}</span>
      </p>
      <p className="mt-1 text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

const MODULES = [
  {
    to: "/crop-doctor",
    icon: ScanSearch,
    title: "AI Crop Doctor",
    tag: "Crop Loss Prevention",
    desc: "Laser-scan diagnostics for Wheat Rust, Cotton Leaf Curl and Rice Blast — severity, remediation and safe dosage in seconds.",
    accent: true,
  },
  {
    to: "/registry",
    icon: BadgeCheck,
    title: "Arhti Compliance",
    tag: "Quality Registry",
    desc: "Arhtis grade lots on moisture, purity, weight and warehouse — and mint a tamper-evident Verified Quality Certificate.",
  },
  {
    to: "/advisory",
    icon: Mic,
    title: "Voice Advisory Hub",
    tag: "6 Regional Languages",
    desc: "Dialect-correct advisories spoken in Urdu, Pashto, Sindhi, Balochi, Brahui and Seraiki for low-literacy farmers.",
  },
  {
    to: "/cold-chain",
    icon: Snowflake,
    title: "Cold-Chain Sentinel",
    tag: "Supply-Chain Risk",
    desc: "Live IoT telemetry during rural transit with conditional escrow — farmers paid in full when produce arrives in spec.",
  },
];

const WORKFLOW = [
  {
    icon: ScanSearch,
    step: "Detect",
    title: "Diagnose in the field",
    desc: "Field agents scan a suspect leaf. The vision engine classifies the pathogen and quantifies severity on the spot.",
  },
  {
    icon: ShieldCheck,
    step: "Verify",
    title: "Grade & certify lots",
    desc: "Arhtis enter lot metrics at the warehouse gate. AgriVision compiles them into a hash-sealed quality certificate.",
  },
  {
    icon: Radio,
    step: "Protect",
    title: "Guard the journey",
    desc: "Sensors stream temperature and humidity from the truck. Escrow pays the farmer automatically — no broker docking.",
  },
];

export default function Home() {
  return (
    <div>
      {/* ---------------- Hero ---------------- */}
      <section className="contour-bg relative overflow-hidden border-b">
        <div className="absolute inset-0 opacity-60">
          <FieldCanvas />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 pb-20 pt-16 sm:px-6 sm:pt-24">
          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="max-w-2xl"
          >
            <p className="inline-flex items-center gap-2 rounded-full border bg-card/70 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
              Live across Punjab · Sindh · KP · Balochistan
            </p>
            <h1 className="font-display mt-5 text-4xl font-semibold leading-[1.08] tracking-tight sm:text-6xl">
              Intelligence for every acre,
              <span className="text-accent"> from soil to sale.</span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              AgriVision AI unifies crop diagnostics, quality certification, multilingual
              advisories and cold-chain escrow — so Pakistan's smallholders lose less to
              disease, doubt and middlemen.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg">
                <Link to="/crop-doctor">
                  Run a diagnosis <ArrowRight className="ml-1.5 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/cold-chain">Watch a live truck</Link>
              </Button>
            </div>
          </motion.div>

          {/* Live impact metrics */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.15, ease: "easeOut" }}
            className="mt-16 grid grid-cols-2 gap-6 rounded-2xl border bg-card/80 p-6 backdrop-blur sm:p-8 lg:grid-cols-4"
          >
            <Metric value={128400} suffix="+" label="Acres under monitoring" />
            <Metric value={31} suffix="%" label="Average post-harvest loss avoided" decimals={0} />
            <Metric value={48200} suffix="+" label="Farmer payments released via escrow" />
            <Metric value={6} suffix="" label="Regional dialects supported" />
          </motion.div>
        </div>
      </section>

      {/* ---------------- Modules ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-accent">Platform modules</p>
            <h2 className="font-display mt-2 text-3xl font-semibold tracking-tight">Four tools, one value chain</h2>
          </div>
          <p className="hidden max-w-sm text-sm text-muted-foreground md:block">
            Every module runs end-to-end in this demo — scan, certify, listen and simulate.
          </p>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {MODULES.map((m, i) => (
            <motion.div
              key={m.to}
              initial={{ opacity: 0, y: 16, scale: 0.98 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.06, ease: "easeOut" }}
            >
              <Link
                to={m.to}
                className="group flex h-full flex-col rounded-2xl border bg-card p-6 transition-colors hover:border-accent/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`grid h-11 w-11 place-items-center rounded-xl ${
                      m.accent ? "bg-accent text-accent-foreground" : "bg-secondary text-foreground"
                    }`}
                  >
                    <m.icon className="h-5 w-5" />
                  </span>
                  <ArrowUpRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
                <p className="mt-5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">{m.tag}</p>
                <h3 className="font-display mt-1 text-xl font-semibold">{m.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{m.desc}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ---------------- Workflow ---------------- */}
      <section className="field-rows border-y bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">How it works</p>
          <h2 className="font-display mt-2 text-3xl font-semibold tracking-tight">Detect, verify, protect</h2>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {WORKFLOW.map((w, i) => (
              <motion.div
                key={w.step}
                initial={{ opacity: 0, y: 16, scale: 0.98 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: i * 0.08, ease: "easeOut" }}
              >
                <Card className="h-full">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-lg bg-primary text-primary-foreground">
                        <w.icon className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                          Step {i + 1} · {w.step}
                        </p>
                        <h3 className="font-display text-lg font-semibold">{w.title}</h3>
                      </div>
                    </div>
                    <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{w.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CTA strip ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-6 rounded-2xl bg-primary p-8 text-primary-foreground sm:p-10 md:flex-row md:items-center">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold">
              <Tractor className="h-4 w-4" />
              <TrendingUp className="h-4 w-4" />
            </div>
            <h2 className="font-display mt-3 text-2xl font-semibold sm:text-3xl">
              Start with a single leaf scan.
            </h2>
            <p className="mt-2 max-w-xl text-sm text-primary-foreground/80">
              Try the pre-loaded Wheat Rust specimen — watch the laser sweep, then read the
              severity, remediation plan and safe pesticide dosage.
            </p>
          </div>
          <Button asChild size="lg" variant="secondary">
            <Link to="/crop-doctor">
              Open the Crop Doctor <ArrowRight className="ml-1.5 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}

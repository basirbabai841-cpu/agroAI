import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { Mic, Volume2, Square, Languages, Radio, Accessibility } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DIALECTS } from "@/lib/data";

const PLAY_DURATION = 7200; // ms of simulated speech per advisory

function Equalizer({ playing }: { playing: boolean }) {
  const bars = 24;
  return (
    <div className="flex h-16 items-end justify-center gap-1" aria-hidden>
      {Array.from({ length: bars }).map((_, i) => (
        <motion.span
          key={i}
          className="eq-bar w-1.5 bg-accent"
          animate={
            playing
              ? { height: [6, 10 + ((i * 37) % 48), 14 + ((i * 53) % 36), 8 + ((i * 29) % 44), 6] }
              : { height: 6 }
          }
          transition={
            playing
              ? { duration: 0.9 + (i % 5) * 0.12, repeat: Infinity, ease: "easeInOut" }
              : { duration: 0.25 }
          }
        />
      ))}
    </div>
  );
}

export default function Advisory() {
  const [langId, setLangId] = useState("urdu");
  const [playing, setPlaying] = useState(false);
  const [wordIdx, setWordIdx] = useState(-1);
  const [engine, setEngine] = useState<"native-tts" | "simulated" | null>(null);
  const timerRef = useRef<number | null>(null);
  const lang = DIALECTS.find((d) => d.id === langId)!;
  const words = lang.phonetic.split(" ");

  const stop = (notify = false) => {
    setPlaying(false);
    setWordIdx(-1);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    if (notify) toast.info("Advisory playback stopped.");
  };

  useEffect(() => () => stop(), []);

  const play = () => {
    if (playing) {
      stop(true);
      return;
    }
    setPlaying(true);
    setWordIdx(0);

    // Try real TTS first (works when a matching voice is installed)
    let usedTts = false;
    if ("speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance(lang.phonetic);
      u.lang = langId === "pashto" ? "ps-AF" : "ur-PK";
      u.rate = 0.92;
      const voices = window.speechSynthesis.getVoices();
      const match = voices.find((v) => v.lang.toLowerCase().startsWith(langId === "pashto" ? "ps" : "ur"));
      if (match) {
        u.voice = match;
        window.speechSynthesis.speak(u);
        usedTts = true;
        setEngine("native-tts");
        toast.success(`Playing advisory in ${lang.label} (native TTS voice).`);
      } else {
        window.speechSynthesis.cancel();
      }
    }
    if (!usedTts) {
      setEngine("simulated");
      toast(`No installed ${lang.label} TTS voice — running AgriVision's simulated regional speech engine.`, {
        description: "Follow the phonetic transcript for exact pronunciation.",
      });
    }

    // Word-by-word highlight driven on a fixed cadence
    const stepMs = PLAY_DURATION / words.length;
    let i = 0;
    timerRef.current = window.setInterval(() => {
      i += 1;
      if (i >= words.length) {
        stop();
        setEngine(null);
        toast.success("Advisory playback complete.");
        return;
      }
      setWordIdx(i);
    }, stepMs);
  };

  const switchLang = (id: string) => {
    if (playing) stop();
    setEngine(null);
    setLangId(id);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent">Voice & Dialect Advisory Hub</p>
        <h1 className="font-display mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">
          Advisories that speak your language
        </h1>
        <p className="mt-3 text-muted-foreground">
          Field advisories rendered in six regional languages with phonetically correct phrasing —
          built for low-literacy farmers who need to hear, not read, what to do next.
        </p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1.3fr]">
        {/* language selector */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Languages className="h-4 w-4 text-accent" /> Choose a dialect
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2">
              {DIALECTS.map((d) => (
                <button
                  key={d.id}
                  onClick={() => switchLang(d.id)}
                  aria-pressed={langId === d.id}
                  className={`rounded-xl border p-3 text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                    langId === d.id ? "border-accent bg-accent/10" : "hover:border-accent/50 bg-secondary/30"
                  }`}
                >
                  <p className="font-display text-lg font-semibold leading-none">{d.native}</p>
                  <p className="mt-1.5 text-sm font-semibold">{d.label}</p>
                  <p className="text-xs text-muted-foreground">{d.region}</p>
                </button>
              ))}
            </div>

            <div className="mt-4 rounded-xl border bg-secondary/40 p-4">
              <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                <Accessibility className="h-4 w-4" /> Literacy-first design
              </p>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Each advisory pairs the native script with a romanized phonetic transcript, so a
                literate family member can confirm exactly what the voice said.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* advisory card */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <Radio className="h-4 w-4 text-accent" /> Advisory · {lang.label}
              </CardTitle>
              <Badge variant="outline">{lang.region}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-1">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Native script</p>
              <AnimatePresence mode="wait">
                <motion.p
                  key={lang.id + "-native"}
                  dir="rtl"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="rounded-xl border bg-secondary/30 p-4 text-right font-display text-xl leading-loose"
                >
                  {lang.advisory}
                </motion.p>
              </AnimatePresence>
            </div>

            <div className="space-y-1">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Phonetic transcript {playing && <span className="text-accent">· speaking…</span>}
              </p>
              <p className="rounded-xl border bg-secondary/30 p-4 text-sm leading-loose">
                {words.map((w, i) => (
                  <span
                    key={i}
                    className={`rounded transition-colors duration-150 ${
                      playing && i === wordIdx ? "bg-accent text-accent-foreground px-1" : ""
                    }`}
                  >
                    {w}{" "}
                  </span>
                ))}
              </p>
            </div>

            <div className="space-y-1">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">English meaning</p>
              <p className="text-sm leading-relaxed text-muted-foreground">{lang.latin}</p>
            </div>

            <div className="rounded-xl border p-4">
              <Equalizer playing={playing} />
              <div className="mt-2 flex flex-col items-center gap-2">
                <Button onClick={play} size="lg" className="w-full sm:w-auto">
                  {playing ? (
                    <>
                      <Square className="mr-2 h-4 w-4" /> Stop advisory
                    </>
                  ) : (
                    <>
                      <Volume2 className="mr-2 h-4 w-4" /> Listen to Advisory
                    </>
                  )}
                </Button>
                <AnimatePresence>
                  {playing && (
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-xs text-muted-foreground"
                    >
                      {engine === "native-tts"
                        ? "Speaking through your device's native voice…"
                        : "Simulated regional voice engine · word-highlight enabled"}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
              <Mic className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              Advisory content: wheat-rust irrigation & fungicide protocol, agronomist-reviewed. In this demo,
              speech uses your device's TTS when a matching voice exists, otherwise a simulated engine with
              word-level highlighting.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

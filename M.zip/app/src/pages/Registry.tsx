import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  BadgeCheck,
  Download,
  FileCheck2,
  Scale,
  Droplets,
  Gem,
  Warehouse,
  History,
  Trash2,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { load, save, uid } from "@/lib/store";

interface Certificate {
  id: string;
  hash: string;
  lotId: string;
  commodity: string;
  moisture: number;
  purity: number;
  weight: number;
  warehouseId: string;
  grade: "A+" | "A" | "B" | "C";
  arhti: string;
  issuedAt: string;
}

const COMMODITIES = ["Wheat", "Rice (Basmati)", "Rice (IRRI)", "Cotton", "Maize", "Sugarcane", "Chickpea", "Onion"];
const ARHTIS = ["Rana Traders, Gujranwala", "Bhatti Commodities, Okara", "Memon & Sons, Hyderabad", "Khan Brothers, Multan"];

function hashFrom(input: string): string {
  let h1 = 0xdeadbeef ^ input.length;
  let h2 = 0x41c6ce57 ^ input.length;
  for (let i = 0; i < input.length; i++) {
    const ch = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const n = (h2 >>> 0).toString(16).padStart(8, "0") + (h1 >>> 0).toString(16).padStart(8, "0");
  return `AV-${n.toUpperCase().slice(0, 4)}-${n.toUpperCase().slice(4, 8)}-${n.toUpperCase().slice(8, 12)}`;
}

function gradeFor(moisture: number, purity: number): Certificate["grade"] {
  const score = (moisture <= 10 ? 2 : moisture <= 12 ? 1 : moisture <= 14 ? 0 : -1) + (purity >= 99 ? 2 : purity >= 98 ? 1 : purity >= 96 ? 0 : -1);
  return score >= 3 ? "A+" : score >= 2 ? "A" : score >= 1 ? "B" : "C";
}

const GRADE_COLORS: Record<Certificate["grade"], string> = {
  "A+": "#15803d",
  A: "#16a34a",
  B: "#b45309",
  C: "#b91c1c",
};

/* Mock QR — deterministic module pattern derived from the hash */
function drawMockQR(ctx: CanvasRenderingContext2D, hash: string, x: number, y: number, size: number) {
  let seed = 7;
  for (const c of hash) seed = (seed * 33 + c.charCodeAt(0)) >>> 0;
  const rand = () => {
    seed = (seed * 1103515245 + 12345) >>> 0;
    return seed / 0xffffffff;
  };
  const n = 21;
  const cell = size / n;
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(x - 6, y - 6, size + 12, size + 12);
  ctx.fillStyle = "#0f1f16";
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      const inEye = (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7);
      if (!inEye && rand() > 0.52) ctx.fillRect(x + c * cell, y + r * cell, cell - 0.5, cell - 0.5);
    }
  }
  const eye = (ex: number, ey: number) => {
    ctx.fillStyle = "#0f1f16";
    ctx.fillRect(ex, ey, cell * 7, cell * 7);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(ex + cell, ey + cell, cell * 5, cell * 5);
    ctx.fillStyle = "#0f1f16";
    ctx.fillRect(ex + cell * 2, ey + cell * 2, cell * 3, cell * 3);
  };
  eye(x, y);
  eye(x + size - cell * 7, y);
  eye(x, y + size - cell * 7);
}

function renderCertificate(cert: Certificate): string {
  const W = 1600;
  const H = 1130;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const dark = "#0f1f16";
  const accent = "#3f8f4f";

  ctx.fillStyle = "#f7f6f1";
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = dark;
  ctx.lineWidth = 6;
  ctx.strokeRect(36, 36, W - 72, H - 72);
  ctx.lineWidth = 2;
  ctx.strokeRect(54, 54, W - 108, H - 108);

  // corner motifs
  ctx.fillStyle = accent;
  for (const [cx, cy, dx, dy] of [
    [54, 54, 1, 1],
    [W - 54, 54, -1, 1],
    [54, H - 54, 1, -1],
    [W - 54, H - 54, -1, -1],
  ] as const) {
    for (let i = 0; i < 4; i++) {
      ctx.fillRect(cx + dx * (i * 14) - (dx < 0 ? 26 : 0), cy + dy * (i * 14) - (dy < 0 ? 8 : 0), 26, 8);
      ctx.fillRect(cx + dx * (i * 14) - (dx < 0 ? 8 : 0), cy + dy * (i * 14) - (dy < 0 ? 26 : 0), 8, 26);
    }
  }

  ctx.textAlign = "center";
  ctx.fillStyle = dark;
  ctx.font = "700 34px Georgia, serif";
  ctx.fillText("AGRIVISION AI", W / 2, 150);
  ctx.font = "500 19px Georgia, serif";
  ctx.fillStyle = "#5a6b5f";
  ctx.fillText("AGRICULTURAL INTELLIGENCE & RISK MANAGEMENT · PAKISTAN", W / 2, 185);
  ctx.font = "700 56px Georgia, serif";
  ctx.fillStyle = dark;
  ctx.fillText("Verified Quality Certificate", W / 2, 280);
  ctx.font = "italic 500 22px Georgia, serif";
  ctx.fillStyle = "#5a6b5f";
  ctx.fillText("This is to certify that the following commodity lot has been graded and verified", W / 2, 330);

  // grade badge
  const g = ctx.createRadialGradient(W / 2, 480, 20, W / 2, 480, 105);
  g.addColorStop(0, GRADE_COLORS[cert.grade]);
  g.addColorStop(1, "#0d1a12");
  ctx.beginPath();
  ctx.arc(W / 2, 480, 92, 0, Math.PI * 2);
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 5;
  ctx.strokeStyle = "#c9a227";
  ctx.stroke();
  ctx.fillStyle = "#fff";
  ctx.font = "800 72px Georgia, serif";
  ctx.fillText(cert.grade, W / 2, 505);
  ctx.font = "600 16px Arial, sans-serif";
  ctx.fillText("QUALITY GRADE", W / 2, 532);

  // details table
  ctx.textAlign = "left";
  const lx = 200;
  const rx = W / 2 + 60;
  let y = 640;
  const row = (label: string, value: string, x: number) => {
    ctx.font = "600 15px Arial, sans-serif";
    ctx.fillStyle = "#5a6b5f";
    ctx.fillText(label.toUpperCase(), x, y);
    ctx.font = "700 26px Arial, sans-serif";
    ctx.fillStyle = dark;
    ctx.fillText(value, x, y + 34);
  };
  row("Lot ID", cert.lotId, lx);
  row("Commodity", cert.commodity, rx);
  y += 84;
  row("Moisture Content", `${cert.moisture.toFixed(1)} %`, lx);
  row("Grain Purity", `${cert.purity.toFixed(1)} %`, rx);
  y += 84;
  row("Net Weight", `${cert.weight.toLocaleString()} kg`, lx);
  row("Warehouse", cert.warehouseId, rx);
  y += 84;
  row("Certifying Arhti", cert.arhti, lx);
  row("Issued (PKT)", new Date(cert.issuedAt).toLocaleString("en-PK", { timeZone: "Asia/Karachi" }), rx);

  // hash + QR
  ctx.textAlign = "left";
  ctx.font = "600 14px Arial, sans-serif";
  ctx.fillStyle = "#5a6b5f";
  ctx.fillText("VERIFICATION HASH (SHA-256 / MOCK)", 430, H - 140);
  ctx.font = "700 20px 'Courier New', monospace";
  ctx.fillStyle = dark;
  ctx.fillText(cert.hash, 430, H - 108);
  drawMockQR(ctx, cert.hash, W - 330, H - 290, 185);

  // seal
  ctx.textAlign = "center";
  const sealX = 230;
  const sealY = H - 140;
  ctx.beginPath();
  ctx.arc(sealX, sealY, 46, 0, Math.PI * 2);
  ctx.strokeStyle = accent;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(sealX, sealY, 37, 0, Math.PI * 2);
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.font = "700 12px Georgia, serif";
  ctx.fillStyle = accent;
  ctx.fillText("AGRIVISION", sealX, sealY - 4);
  ctx.fillText("VERIFIED", sealX, sealY + 12);

  ctx.textAlign = "center";
  ctx.font = "500 16px Arial, sans-serif";
  ctx.fillStyle = "#5a6b5f";
  ctx.fillText("Verify this certificate at agrivision.pk/verify · Non-transferable without the issuing Arhti's countersign", W / 2, H - 60);

  return canvas.toDataURL("image/png");
}

export default function Registry() {
  const [certificates, setCertificates] = useState<Certificate[]>(() => load<Certificate[]>("arhti-certificates", []));
  const [commodity, setCommodity] = useState("Wheat");
  const [arhti, setArhti] = useState(ARHTIS[0]);
  const [moisture, setMoisture] = useState("11.4");
  const [purity, setPurity] = useState("98.2");
  const [weight, setWeight] = useState("4200");
  const [warehouseId, setWarehouseId] = useState("WH-LHR-014");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [latest, setLatest] = useState<Certificate | null>(null);
  const certImgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    save("arhti-certificates", certificates);
  }, [certificates]);

  const previewGrade = useMemo(() => {
    const m = parseFloat(moisture);
    const p = parseFloat(purity);
    if (isNaN(m) || isNaN(p)) return null;
    return gradeFor(m, p);
  }, [moisture, purity]);

  const validate = (): Certificate | null => {
    const e: Record<string, string> = {};
    const m = parseFloat(moisture);
    const p = parseFloat(purity);
    const w = parseFloat(weight);
    if (isNaN(m) || m < 4 || m > 30) e.moisture = "Enter moisture between 4–30%.";
    if (isNaN(p) || p < 50 || p > 100) e.purity = "Enter purity between 50–100%.";
    if (isNaN(w) || w <= 0 || w > 100000) e.weight = "Enter a valid weight in kg.";
    if (!/^WH-[A-Z]{2,8}-\d{1,5}$/i.test(warehouseId.trim())) e.warehouseId = "Format: WH-CITY-### (e.g. WH-LHR-014).";
    setErrors(e);
    if (Object.keys(e).length > 0) return null;

    const cert: Certificate = {
      id: uid("LOT"),
      hash: hashFrom(`${commodity}${moisture}${purity}${weight}${warehouseId}${Date.now()}`),
      lotId: uid("LOT").replace("LOT-", "PK-LOT-"),
      commodity,
      moisture: m,
      purity: p,
      weight: w,
      warehouseId: warehouseId.trim().toUpperCase(),
      grade: gradeFor(m, p),
      arhti,
      issuedAt: new Date().toISOString(),
    };
    return cert;
  };

  const issue = () => {
    const cert = validate();
    if (!cert) {
      toast.error("Please fix the highlighted fields before issuing.");
      return;
    }
    setCertificates((c) => [cert, ...c]);
    setLatest(cert);
    toast.success(`Certificate ${cert.hash} issued — Grade ${cert.grade}`);
  };

  const download = () => {
    if (!latest) return;
    const a = document.createElement("a");
    a.href = renderCertificate(latest);
    a.download = `AgriVision-Quality-Certificate-${latest.lotId}.png`;
    a.click();
    toast.success("Certificate downloaded as PNG.");
  };

  const field = (
    id: string,
    label: string,
    icon: React.ReactNode,
    value: string,
    set: (v: string) => void,
    placeholder: string
  ) => (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {icon} {label}
      </Label>
      <Input
        id={id}
        value={value}
        onChange={(e) => set(e.target.value)}
        placeholder={placeholder}
        inputMode="decimal"
        aria-invalid={!!errors[id]}
      />
      {errors[id] && <p className="text-xs text-destructive">{errors[id]}</p>}
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent">Arhti Compliance & Quality Registry</p>
        <h1 className="font-display mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">Digital Grading Portal</h1>
        <p className="mt-3 text-muted-foreground">
          Arhtis record lot metrics at the warehouse gate. AgriVision compiles them into a
          tamper-evident certificate — unique hash, Karachi-time timestamp, digital seal and
          verification QR — ready to hand to the buyer.
        </p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        {/* form */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Scale className="h-4 w-4 text-accent" /> Lot metrics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Commodity</Label>
                <Select value={commodity} onValueChange={setCommodity}>
                  <SelectTrigger aria-label="Commodity"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {COMMODITIES.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Certifying Arhti</Label>
                <Select value={arhti} onValueChange={setArhti}>
                  <SelectTrigger aria-label="Arhti"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ARHTIS.map((a) => (
                      <SelectItem key={a} value={a}>{a}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {field("moisture", "Moisture content %", <Droplets className="h-3.5 w-3.5" />, moisture, setMoisture, "e.g. 11.4")}
            {field("purity", "Grain purity grade %", <Gem className="h-3.5 w-3.5" />, purity, setPurity, "e.g. 98.2")}
            {field("weight", "Net weight (kg)", <Scale className="h-3.5 w-3.5" />, weight, setWeight, "e.g. 4200")}
            {field("warehouseId", "Warehouse ID", <Warehouse className="h-3.5 w-3.5" />, warehouseId, setWarehouseId, "WH-LHR-014")}

            <div className="flex items-center justify-between rounded-xl border bg-secondary/40 px-4 py-3">
              <p className="text-sm font-medium text-muted-foreground">Projected grade</p>
              {previewGrade ? (
                <Badge className="text-sm" style={{ backgroundColor: GRADE_COLORS[previewGrade] }}>
                  Grade {previewGrade}
                </Badge>
              ) : (
                <span className="text-sm text-muted-foreground">—</span>
              )}
            </div>

            <Button onClick={issue} className="w-full" size="lg">
              <BadgeCheck className="mr-1.5 h-4 w-4" /> Issue Verified Certificate
            </Button>
          </CardContent>
        </Card>

        {/* certificate preview */}
        <div className="space-y-4">
          <AnimatePresence mode="wait">
            {latest ? (
              <motion.div
                key={latest.hash}
                initial={{ opacity: 0, y: 14, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <ShieldCheck className="h-4 w-4 text-success" /> Certificate {latest.hash}
                      </CardTitle>
                      <Button variant="outline" size="sm" onClick={download}>
                        <Download className="mr-1 h-3.5 w-3.5" /> Download PNG
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-hidden rounded-lg border bg-white">
                      <img
                        ref={certImgRef}
                        src={renderCertificate(latest)}
                        alt="AgriVision Verified Quality Certificate preview"
                        className="w-full"
                      />
                    </div>
                    <p className="mt-3 text-xs text-muted-foreground">
                      Grade {latest.grade} · {latest.commodity} · {latest.weight.toLocaleString()} kg · sealed{" "}
                      {new Date(latest.issuedAt).toLocaleString("en-PK", { timeZone: "Asia/Karachi" })} PKT
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <Card className="flex min-h-72 flex-col items-center justify-center gap-3 p-8 text-center text-muted-foreground">
                  <FileCheck2 className="h-10 w-10 opacity-40" />
                  <p className="max-w-xs text-sm">
                    Complete the lot metrics and issue a certificate — the sealed, downloadable
                    document renders here.
                  </p>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {certificates.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <History className="h-4 w-4 text-accent" /> Registry ({certificates.length})
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setCertificates([]);
                      toast.info("Registry cleared.");
                    }}
                  >
                    <Trash2 className="mr-1 h-3.5 w-3.5" /> Clear
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {certificates.slice(0, 6).map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setLatest(c)}
                    className="flex w-full items-center justify-between gap-3 rounded-lg border bg-secondary/30 px-3 py-2.5 text-left text-sm transition-colors hover:border-accent/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-medium">
                        {c.commodity} · {c.weight.toLocaleString()} kg · {c.warehouseId}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {c.hash} · {new Date(c.issuedAt).toLocaleDateString("en-PK", { timeZone: "Asia/Karachi" })}
                      </p>
                    </div>
                    <Badge variant="outline">Grade {c.grade}</Badge>
                  </button>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

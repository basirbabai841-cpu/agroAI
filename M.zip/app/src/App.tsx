import { Routes, Route } from "react-router";
import AppLayout from "./components/AppLayout";
import Home from "./pages/Home";
import CropDoctor from "./pages/CropDoctor";
import Registry from "./pages/Registry";
import Advisory from "./pages/Advisory";
import ColdChain from "./pages/ColdChain";

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/crop-doctor" element={<CropDoctor />} />
        <Route path="/registry" element={<Registry />} />
        <Route path="/advisory" element={<Advisory />} />
        <Route path="/cold-chain" element={<ColdChain />} />
        <Route path="*" element={<Home />} />
      </Route>
    </Routes>
  );
}
